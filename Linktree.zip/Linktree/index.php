
<!-- INFO -->

<!-- ALLE BEREICHE DIE ZU ÄNDERN SIND WURDEN MIT #text MARKIERT UND BESCHRIEBEN BITTE NICHTS ANDERS ÄNDERN WENN DU DICH DAMIT NICHT AUSKENNST ES KÖNNTE DIE DATEI BESCHÄDIGEN ODER NICHT MEHR ERREICHBAR WERDEN HIERZU SIND FOLGENDE KENNTNISSE NÖTIG HTML, CSS, PHP, JAVASCHRIPT -->

<!-- INFO ENDE -->

<?php

date_default_timezone_set('Europe/Berlin');


$sitename = 'templatedesigns24.de'; # SETZE HIER DEINEN SEITEN NAMEN
$domain = 'DOMAIN'; # SETZE HIER DEINE DOMAIN WICHTIG!!
$logo = 'logo.png'; # SETZE HIER DEIN LOGO

$linktree = array(
    array(
        'displayName' => 'NAME 1', # Setze hier den namen der zum link Führt
        'url' => ' LINK ' #SETZE HIER DEINEN LINK
    ),
    array(
        'displayName' => 'NAME 2', # Setze hier den namen der zum link Führt
        'url' => ' LINK ' #SETZE HIER DEINEN LINK
    ),
    array(
        'displayName' => 'NAME 3', # Setze hier den namen der zum link Führt
        'url' => ' LINK ' #SETZE HIER DEINEN LINK
    ),
    array(
        'displayName' => 'NAME 4', # Setze hier den namen der zum link Führt
        'url' => ' LINK ' #SETZE HIER DEINEN LINK
    ),	
    array(
        'displayName' => 'NAME 5', # Setze hier den namen der zum link Führt
        'url' => ' LINK ' #SETZE HIER DEINEN LINK
    ),
    array(
        'displayName' => 'NAME 6', # Setze hier den namen der zum link Führt
        'url' => ' LINK ' #SETZE HIER DEINEN LINK
    ),
    array(
        'displayName' => 'NAME 7', # Setze hier den namen der zum link Führt
        'url' => ' LINK ' #SETZE HIER DEINEN LINK
    )
);

### INFO ###

# Wenn du noch mehr links brauchst kopiere einfach folgendes 

    # array(
     #   'displayName' => 'NAME 7', # Setze hier den namen der zum link Führt
    #    'url' => ' LINK ' #SETZE HIER DEINEN LINK
   # )

# Vergesse nicht die "#" zu entfernen und achte darauf das nur das letzte ")" kein komma hat also wenn du weitere links hinzufügst dann füge 
# Bei ")" ein komma hinzu das es wie folgt aussieht ")," und achte dabei drauf das der letzte link kein komma hat wie man oben sieht.

### INFO ENDE ###		
		
$socialMedia = array(
    array(
        'icon' => '<i class="fas fa-envelope"></i>',
        'url' => 'mailto: HIER DEINE EMAIL ADRESSE ' #Setze hier deine Email Adresse rein
    )
);


$titleColor = '#FF7F7F'; 
$titleHoverColor = '#7F3F3F'; 
$textColor = '#C0C0C0'; 
$secondaryColor = '#FF0000'; 
$secondaryHoverColor = '#880000'; 

$backgroundColor = '#13161B'; 
$buttonColor = '#242936'; 
$buttonShadowColor = '#353535'; 
$backgroundImage = 'img/hintergrund.jpeg'; # HIER KANNST DU DEN HINTERGRUND ÄNDERN


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        
        <title><?= $sitename ?></title>
        <meta content=" DEINE BESCHREIBUNG " name="description"> <!-- Setze hier deine Beschreibung -->
        <meta content=" SETZE HIER DEINE TAGS" name="keywords"> <!-- Setze hier deine Tags zb "GTA, RPServer" -->

        <link href="<?= $logo ?>" rel="icon">
        <link href="<?= $logo ?>" rel="apple-touch-icon">
        
        <link href="css/fonts.css" rel="stylesheet">

        <script src="js/atw.js" crossorigin="anonymous"></script>
        

        <script src="js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

        <link href="css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
        <style>

            body {
                font-family: "Open Sans", sans-serif;
                color: <?= $textColor?>;
            }
            .fixedBackground {
                position: fixed;
                inset: 0px;
                z-index: -1;
                <?php
                if($backgroundImage != 'NONE') {
                    echo 'background-image: url(' . $backgroundImage . ');';
                }
                ?>
                background-image: url(<?= $backgroundImage?>);
                background-position: center center;
                background-size: cover;
                background-repeat: no-repeat;
                background-color: <?= $backgroundColor?>;
            }

            a {
                transition: 0.3s;
                color: <?= $secondaryColor?>;
                text-decoration: none;
            }

            a:hover {
                transition: 0.3s;
                color: <?= $secondaryHoverColor?>;
                text-decoration: none;
            }

            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            .font-primary {
                font-family: "Raleway", sans-serif;
            }


            hr {
                margin: 30px 28% 30px 28%;
            }

            section {
                padding: 10px 0;
                overflow: hidden;
            }

            .section-title {
                text-align: center;
                padding-bottom: 30px;
            }

            .section-title img {
                width: 128px;
                border-radius: 50%;
                margin: 20px;
            }

            .section-title h2 {
                font-size: 32px;
                font-weight: 600;
                margin-bottom: 10px;
                padding-bottom: 0;
                transition: 0.3s;
                color: <?= $titleColor?>;
            }
            .section-title h2:hover {
                transition: 0.3s;
                color: <?= $titleHoverColor?>;
            }

            .section-title p {
                margin-bottom: 0;
            }

            
            .linktree {
                text-align: -webkit-center;
            }
            .linklist {
                max-width: 500px;
                margin: 0 10%;
            }
            .linklist a {
                transition: 0.3s;
                background-color: <?= $buttonColor; ?>;
                padding: 15px;
                border-radius: 15px;
                box-shadow: <?= $buttonShadowColor; ?> 4px 4px 0px 0px;
                margin: 7px 0;
            }
            .linklist a:hover {
                transition: 0.3s;
                transform: translate(-4px, -4px);
            }
            
            .social-links a {
                font-size: 18px;
                display: inline-block;
                background: <?= $backgroundColor?>;
                line-height: 1;
                padding: 8px 0;
                margin-right: 4px;
                border-radius: 50%;
                text-align: center;
                width: 36px;
                height: 36px;
            }

            .social-links a:hover {
                background: <?= $backgroundContentColor?>;
                text-decoration: none;
            }

			.unterseitenlinks {
               background-color:#242936;
               padding:12px;
			   border-radius:12px;
               box-shadow: #353535 4px 4px 0px 0px;
			   margin: 7px 0;
            }
        </style>
    </head>
    
    <body>

        <div class="fixedBackground"></div>

        <main>
            <section class="linktree">
                <div class="container">
                    
                    <div class="section-title">
                        <img src="<?= $logo ?>"></img>
					
					<!-- Setze hier Dein Name, Projektnamen, -->
					
                        <h2>templatedesigns24.de 
							
							<!-- ENTFERNE VON HIER BIS "HAKEN ENDE" UM DEN BLAUEN HAKEN ZU ENTFERNEN -->
							
							<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="35" height="35" viewBox="0 0 48 48">
<polygon fill="#42a5f5" points="29.62,3 33.053,8.308 39.367,8.624 39.686,14.937 44.997,18.367 42.116,23.995 45,29.62 39.692,33.053 39.376,39.367 33.063,39.686 29.633,44.997 24.005,42.116 18.38,45 14.947,39.692 8.633,39.376 8.314,33.063 3.003,29.633 5.884,24.005 3,18.38 8.308,14.947 8.624,8.633 14.937,8.314 18.367,3.003 23.995,5.884"></polygon><polygon fill="#fff" points="21.396,31.255 14.899,24.76 17.021,22.639 21.428,27.046 30.996,17.772 33.084,19.926"></polygon>
</svg>

<!-- HAKEN ENDE -->
							
					</h2>
					
					
					<!-- Setze hier deine Überschrift -->
                        <p> HIER KOMMT DEINE ÜBERSCHRIFT HIN</p>
                    </div>
                    
                    <hr>

                    <div class="linklist">
                        <div class="row">
                            <?php
                            foreach ($linktree as $list) {
                                echo '<a class="link" href="' . $list['url'] . '" target="_blank">' . $list['icon'] . ' ' . $list['displayName'] . '</a>';
                            }
                            ?>
                        </div>
                    </div>

                    <hr>

                    <div class="social-links text-center" style="padding-top: 20px;">
                            <?php
                            foreach ($socialMedia as $list) {
                                echo '<a href="' . $list['url'] . '" target="_blank">' . $list['icon'] . '</a>';
                            }
                            ?>
                    </div>

                <div>
					<br>
					<!-- Aktuallisierung kann auch entfernt werden wenn man dies nicht braucht --> 
				   <p style="text-align: center"> Zuletzt aktuallisiert 04.09.2023 </p>	
					<hr>
					<!-- Copyright --> 
		           <p style="text-align: center"> Copyright &copy; 2023-<script>document.write(new Date().getFullYear())</script> "DEINE DOMAIN" - Alle Rechte vorbehalten.</p>
					
					<!-- Wenn du uns Unterstützen möchtest lasse das hier stehen sonst entferne es -->
					<p style="text-align: center"> Created by <a href="https://templatedesigns24.de">TemplateDesigns24.de</a> </p>
				</div>	

                </div>
            </section>
        </main>
    </body>
</html>